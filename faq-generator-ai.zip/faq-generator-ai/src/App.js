import React, { useState } from "react";
import "./styles.css";

const initialFaqs = [
  { q: "What are your working hours?", a: "We are open from 9 AM to 6 PM, Monday to Friday." },
  { q: "Do you offer refunds?", a: "Yes, refunds are available within 14 days of purchase." },
  { q: "How can I contact support?", a: "You can email us at support@example.com." }
];

function App() {
  const [faqs, setFaqs] = useState(initialFaqs);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);

  const handleAsk = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    const userMessage = { from: "user", text: input };
    const lower = input.toLowerCase();
    const found = faqs.find(f => lower.includes(f.q.split(" ")[0].toLowerCase()) || lower.includes(f.q.toLowerCase()));
    const botMessage = found
      ? { from: "bot", text: found.a }
      : { from: "bot", text: "Sorry, I couldn't find that. Please contact support." };

    setMessages([...messages, userMessage, botMessage]);
    setInput("");
  };

  const addFaq = () => {
    const q = prompt("Enter question:");
    const a = prompt("Enter answer:");
    if (q && a) setFaqs([...faqs, { q, a }]);
  };

  return (
    <div className="container">
      <h1>Automated FAQ Generator & Responder</h1>
      <p className="subtitle">AI-like FAQ responder for small business websites</p>

      <div className="main">
        <div className="chat">
          <h2>Chatbot</h2>
          <div className="messages">
            {messages.map((m, i) => (
              <div key={i} className={\`msg \${m.from}\`}>{m.text}</div>
            ))}
          </div>
          <form onSubmit={handleAsk} className="input-area">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question..."
            />
            <button type="submit">Send</button>
          </form>
        </div>

        <div className="faq">
          <h2>FAQ List (Admin)</h2>
          {faqs.map((f, i) => (
            <div key={i} className="faq-item">
              <strong>Q:</strong> {f.q}<br />
              <strong>A:</strong> {f.a}
            </div>
          ))}
          <button onClick={addFaq}>+ Add FAQ</button>
        </div>
      </div>

      <footer>© 2025 FAQ Generator AI | Demo by Pallavi & Arshitha</footer>
    </div>
  );
}

export default App;
